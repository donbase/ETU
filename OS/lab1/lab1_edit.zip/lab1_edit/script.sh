#!/bin/bash
gcc main.c -o prog
./prog
rm prog

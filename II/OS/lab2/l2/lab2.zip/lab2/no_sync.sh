#!/bin/bash
gcc prog1.c -o prog -lpthread
./prog
rm prog

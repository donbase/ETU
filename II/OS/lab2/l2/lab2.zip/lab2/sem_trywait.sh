#!/bin/bash
gcc prog3.c -o prog -lpthread
./prog
rm prog

#!/bin/bash
gcc prog2.c -o prog -lpthread
./prog
rm prog

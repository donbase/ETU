#!/bin/bash

gcc -o prog1 child.c

gcc -o prog father.c

./prog alpha beta gamma delta

rm prog prog1

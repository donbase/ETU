#!/bin/bash

gcc ready2.c -o prog2
./prog2
rm prog2

#!/bin/bash

gcc ready1.c -o prog1
./prog1
rm prog1
